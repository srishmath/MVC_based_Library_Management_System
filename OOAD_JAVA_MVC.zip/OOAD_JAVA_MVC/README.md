To run the code -
mvn spring-boot:run
